import { createContext } from "react";

export const BusStopsContext = createContext(null);
export const UniqueStopListContext = createContext(null);
export const BusServicesContext = createContext(null);
export const UniqueBusServicesContext = createContext(null);
export const BusRoutesContext = createContext(null);
